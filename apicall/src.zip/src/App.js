

import React from 'react'
import  ProductComponent  from './components/ProductComponent'

const App = () => {
  return (
    <div>
        <ProductComponent/>
    </div>
  )
}

export default App
