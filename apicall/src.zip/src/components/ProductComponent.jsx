

import { useEffect } from "react";

const ProductComponent = () => {
  
  const fetchProductDetail = async () => {
     await
      fetch(`https://fakestoreapi.com/products/${id}`)
      .then((res)=>{
        return res.json();
      })
      .then((data)=>{
        console.log(data);
      }) 
  }
  const useEffect=(()=>{
    fetchProductDetail();
  },[]);

 
};

export default ProductComponent;
